package no.hvl.dat108;

public abstract class UrlMappings {
    
    public static final String LIST_URL = "deltagerliste";
    public static final String LOGIN_URL = "logginn";
    public static final String LOGOUT_URL = "ferdig";
    public static final String CONFIRM_URL = "WEB-INF/paameldingsbekreftelse.jsp";
}